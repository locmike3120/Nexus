CREATE DATABASE EventmanagerWF
GO
USE EventmanagerWF
GO

CREATE TABLE partner
(
pn_id VARCHAR(20) PRIMARY KEY,
pn_name NVARCHAR(255),
pn_age DATE,
pn_gender NVARCHAR(100),
pn_phone VARCHAR(10),
pn_email VARCHAR(255),
pn_address NVARCHAR(255),
event_id VARCHAR(10) FOREIGN KEY REFERENCES eventt(ev_id) null
)
GO
INSERT INTO partner VALUES
('EV001','KM001',N'Nguyễn Thị Đệ','2000/11/03',N'Nữ','0855144663','hoangthien3120@gmail.com',N'Gia Lâm - Hà Nội')
GO
INSERT INTO partner VALUES
('EV002','KM002',N'Trần Thị Hậu','1998/08/28',N'Nữ','082212228','hautran280898@gmail.com',N'Gia Lâm - Hà Nội')
GO
INSERT INTO partner VALUES
('EV001','KM003',N'Chu Đức Nam','2000/08/28',N'Nam','0835083089','namchicken@gmail.com',N'Tam Cốc - Ninh Bình')
GO
CREATE TABLE employee
(
ep_ID VARCHAR(20) PRIMARY KEY,
ep_name NVARCHAR(255) not null,
ep_age DATE not null,
ep_gender NVARCHAR(100) not null,
ep_phone VARCHAR(10) not null,
ep_email VARCHAR(255) not null,
ep_address NVARCHAR(255)
)
GO
INSERT INTO employee VALUES
('NV001',N'Trần Văn Hoa','1998/08/28',N'Nam','082212228','hautran280898@gmail.com',N'Gia Lâm - Hà Nam')
GO
INSERT INTO employee VALUES
('NV002',N'Nguyễn Thị Thúy','1998/08/28',N'Nữ','082212228','hautran@gmail.com',N'Gia Lâm - Hà Giang')
GO
INSERT INTO employee VALUES
('NV003',N'Hoang Văn Thụ','1998/08/28',N'Nam','082212228','hau280898@gmail.com',N'Gia Lâm - Hồ Chí Minh')
GO
CREATE TABLE event_type
(
et_id VARCHAR(20) PRIMARY KEY,
et_name NVARCHAR(255)
)
INSERT INTO event_type VALUES
('VH',N'Văn Hóa')
GO
INSERT INTO event_type VALUES
('TT',N'Thể Thao')
GO
INSERT INTO event_type VALUES
('DL',N'Du Lịch')
GO
INSERT INTO event_type VALUES
('XH',N'Xã Hội')
GO
INSERT INTO event_type VALUES
('GD',N'Giáo Dục')
GO
INSERT INTO event_type VALUES
('TH',N'Tổng Hợp')
GO
CREATE TABLE eventt
(
ev_id VARCHAR(10) PRIMARY KEY,
ev_type_id VARCHAR(20) FOREIGN KEY REFERENCES event_type(et_id),
ev_name NVARCHAR(255),
ev_from_date DATE,
ev_to_date DATE,
ev_detail NVARCHAR(255)
)
GO
INSERT INTO eventt VALUES
('EV001','VH',N'Tuyên truyền cách phòng tránh dịch covid 2020','2020/05/01','2020/05/03',N'Tuyên truyền các thứ')
GO
INSERT INTO eventt VALUES
('EV002','TH',N'Tuyên truyền cách phòng tránh dịch covid 2020','2020/05/01','2020/05/03',N'Tuyên truyền các thứ')
GO
CREATE TABLE show
(
show_ev_id VARCHAR(10) FOREIGN KEY REFERENCES eventt(ev_id),
show_id VARCHAR(10) PRIMARY KEY,
show_name NVARCHAR(255),
show_ep_id varchar(20) FOREIGN KEY REFERENCES employee(ep_id),
show_start_day DATETIME,
show_end_day DATETIME,
show_detail NTEXT
)
GO
INSERT INTO show VALUES('EV001',1,N'Đốt lửa trại','NV001','2020/05/05 03:04 AM','2020/06/06 03:44 AM',N'aaaaaaa')
GO
INSERT INTO show VALUES('EV002','1a',N'Đốt lửa trại','NV001','2020/05/05 03:04 AM','2020/06/06 03:44 AM',N'aaaaaaa')
GO
CREATE TABLE cost
(
event_id VARCHAR(10) FOREIGN KEY REFERENCES eventt(ev_id),
cost_id VARCHAR(20) PRIMARY KEY ,
category NVARCHAR(255),
expense FLOAT,
description NTEXT
)
GO
GO
INSERT INTO cost VALUES
('EV001', 'C01',N'Ao con khi', 1200000.00, N'aaaaaaaa')
GO
INSERT INTO cost VALUES
('EV002', 'C11',N'Ao con khi', 1200000.00, N'aaaaaaaa')
GO
CREATE TABLE Account
(
id int primary key identity(1,1),
username VARCHAR(25),
password VARCHAR(25),
ad_name NVARCHAR(25),
ad_age DATE,
ad_gender NVARCHAR(20),
ad_phone VARCHAR(10),
ad_email VARCHAR(255),
ad_address NVARCHAR(255)
)
GO
select * from Account
delete from Account
insert into Account values ('admin', '123456', 'Loc', '2000-12-19', N'Nữ', '0123456789', 'loc.nguyen1912@gmail.com', N'Hà Nội')
drop table Account